import React, { Component, Fragment } from 'react';
import { EuiInMemoryTable } from '@elastic/eui';
import { Moment } from 'moment';
import { getProperties, getDocuments } from '../Service/ElasticSearchService';
import './Content.css';
import { EuiTableFieldDataColumnType } from '@elastic/eui';

interface ContentProps { elasticUrl: string, indexName: string, date: Moment  };
interface ContentState { documents: Object[], isLoading: boolean, properties: EuiTableFieldDataColumnType<Object>[] };

let debounceTimeoutId: NodeJS.Timeout;
let requestTimeoutId: NodeJS.Timeout;

export class Content extends Component<ContentProps, ContentState>{

    constructor(props: ContentProps) {
        super(props);
        this.state = { documents : [] = [], isLoading: false, properties: [] = [] };
      }

    async componentDidMount()
    {        
        await this.setProperties(); 
        await this.setDocuments();
    }

    async setProperties()
    {
        let columns : EuiTableFieldDataColumnType<Object>[] = []; 
        if(this.props.elasticUrl && this.props.indexName) {               
            let result = await getProperties(this.props.elasticUrl, this.props.indexName); 
            if(result){
                console.log(result);
                
                Object.keys(result).forEach(prop => {
                       columns.push({ field: prop, name: prop.toUpperCase() });
                });
                columns.push({ field: "raw", name: "Raw" });
                this.setState({properties: columns});
            } 
            else{
                columns.push({ field: "raw", name: "Raw" });
                this.setState({properties: columns});
            }        
        }
        else{
            console.log('Invalid Data : ' + this.props.elasticUrl + '::' + this.props.indexName)
        }
    }

    async setDocuments()
    {
        if(this.props.elasticUrl && this.props.indexName) {               
            let result =  await getDocuments(this.props.elasticUrl, this.props.indexName, this.props.date);    
            if(result){
                let docs : object[] = []; 
                result.forEach(doc => { 
                    let value =  doc["_source"];
                    if(value)
                    {                  
                        docs.push(value);
                    }
                });       
                
                console.log(docs);
                this.setState({documents : docs})
            }                 
        }
        else{
            console.log('Invalid Data : ' + this.props.elasticUrl + '::' + this.props.indexName)
        }
    }

    onQueryChange = (query: any) => {
        clearTimeout(debounceTimeoutId);
        clearTimeout(requestTimeoutId);
    
        debounceTimeoutId = setTimeout(() => {
          this.setState({
            isLoading: true,
          });
    
          requestTimeoutId = setTimeout(() => {  }, 1000); }, 300);
      };

    render(){   
        const search = {
            onChange: this.onQueryChange,
            box: {
              incremental: true,
            },
          };

        return(
        <Fragment>
            <EuiInMemoryTable className="table"
              tableLayout={'auto'}
              items={this.state.documents}
              loading={this.state.isLoading}
              columns={this.state.properties}
              search={search}
              pagination={true}
              sorting={true}
            />
          </Fragment>);
    }
}

