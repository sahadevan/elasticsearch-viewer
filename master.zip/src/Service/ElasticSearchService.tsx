import { Moment } from "moment";

export async function getIndices(elasticUrl: string) {    
    let indices: string[] = [];
   try{    
       if(elasticUrl){
        let response = await fetch(elasticUrl + '_aliases');
        if(response && response.ok)
        {
            let aliases = await response.json();
            if(aliases)
            {
                Object.keys(aliases).forEach((index) => {
                    console.log(index);
                    indices.push(index);
            });
            }
        }  
        return indices;
    }else{
        console.log('Invalid ElasticSearch URL :' + elasticUrl);
    }
   }catch(error){
    console.log(error);
    return indices;
   }
}

export async function getClusterHealth(elasticUrl: string){
    let health : string = "";
    try{    
        if(elasticUrl){
         let response = await fetch(elasticUrl + '_cat/health');
         if(response && response.ok)
         {
            var result = await response.body?.getReader().read();
            health =  new TextDecoder("utf-8").decode(result?.value);
            health = health.split(" ")[3];
            console.log('Elasticsearch cluster health: '+ health);             
         }  
         return health;
     }else{
         console.log('Invalid ElasticSearch URL :' + elasticUrl);
     }
    }catch(error){
     console.log(error);
     return health;
    }
}

export async function getProperties(elasticUrl: string, indexName: string)
{
    let properties : [] = [];
    try{    
        if(elasticUrl && indexName){
         let response = await fetch(elasticUrl + indexName + '/_mapping');
         if(response && response.ok)
         {
            let mapping = await response.json();
            if(mapping)
            {                
                console.log(mapping);
                properties = mapping[indexName]["mappings"]["properties"];
                return properties;
            }
         }  
     }else{
         console.log('Invalid data provider :' + elasticUrl + '::' + indexName);         
     }

     return properties;
    }catch(error){
     console.log(error);
     return properties;
    }
}

export async function getDocuments(elasticUrl: string, indexName: string, date: Moment)
{
    let documents : [] = [];
    try{    
        if(elasticUrl && indexName){
         let response = await fetch(elasticUrl + indexName + '/_search');
         if(response && response.ok)
         {
            let docs = await response.json();
            if(docs)
            {
                documents = docs["hits"]["hits"];
                console.log(documents);
            }
         }  
     }else{
         console.log('Invalid data provider :' + elasticUrl + '::' + indexName + '::' + date);        
     }
     return documents;
    }catch(error){
     console.log(error);
     return documents;
    }
}